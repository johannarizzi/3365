"use strict";
var car;
function submitCar() {
    var errores = 0;
    var plateInput = document.getElementById("plateInput");
    var brandInput = document.getElementById("brandInput");
    var colorInput = document.getElementById("colorInput");
    //EX1. Validar los campos de matricula, marca y color, antes de hacer el new Car
    var expreg = /^\d{4}-[A-Z]{3}$/;
    var expreg2 = /^[a-zA-Z\s]+$/;
    if (expreg.test(plateInput.value)) {
    }
    else {
        alert("La matrícula NO es correcta, deber contenet 4 números y 3 letras en mayúscula 0000-XXX");
        return false;
    }
    if (expreg2.test(brandInput.value)) {
    }
    else {
        alert("La marca NO es correcta, debe contener sólo letras");
        return false;
    }
    if (expreg2.test(colorInput.value)) {
    }
    else {
        alert("El color NO es correcto, debe contener sólo letras");
        return false;
    }
    car = new Car(plateInput.value, colorInput.value, brandInput.value);
    showVehicle();
    showWheelForm();
}
function showVehicle() {
    var carTitle = document.getElementById("carTitle");
    var plateOutput = document.getElementById("plateOutput");
    var brandOutput = document.getElementById("brandOutput");
    var colorOutput = document.getElementById("colorOutput");
    carTitle.innerText = "Car:";
    plateOutput.innerText = "Plate: " + car.plate;
    brandOutput.innerText = "Brand: " + car.brand;
    colorOutput.innerText = "Color: " + car.color;
}
function submitWheelForm() {
    var errores = 0;
    //EX2. Solo hacer el "new Wheel" si las 4 ruedas son correctas
    //EX3. Una rueda correcta deberá tener un diámetro entre 1 y 2. Crear una función para validarlas
    for (var i = 1; i <= 4; i++) {
        var brandWheel = document.getElementById("brandWheel" + i);
        var diameterWheel = document.getElementById("diameterWheel" + i);
        var expregBrand = /^[a-zA-Z\s]+$/;
        var expregWheel = /^[1-2]{1}$/;
        if (expregBrand.test(brandWheel.value)) {
        }
        else {
            alert("Debe completar todos los campos, la marca sólo pude contener letras");
            return false;
        }
        if (expregWheel.test(diameterWheel.value)) {
        }
        else {
            alert("Debe completar todos los campos, el díametro sólo puede ser entre 1 y 2");
            return false;
        }
        var wheel_generica = new Wheel(Number(diameterWheel.value), brandWheel.value);
        car.addWheel(wheel_generica);
    }
    console.log(car);
    showWheels();
}
function showWheels() {
    //EX4. Optimizar la función showWheels
    var wheelTitle = document.getElementById("wheelTitle");
    var wheelOutput = document.getElementById("wheelOutput");
    wheelTitle.innerText = "Wheels:";
    /* wheelOutput1.innerText = "Wheel 1:  " + "Brand: " + car.wheels[0].brand + "  Diameter: " + car.wheels[0].diameter;
    wheelOutput2.innerText = "Wheel 2:  " + "Brand: " + car.wheels[1].brand + "  Diameter: " + car.wheels[1].diameter;
    wheelOutput3.innerText = "Wheel 3:  " + "Brand: " + car.wheels[2].brand + "  Diameter: " + car.wheels[2].diameter;
    wheelOutput4.innerText = "Wheel 4:  " + "Brand: " + car.wheels[3].brand + "  Diameter: " + car.wheels[3].diameter;
*/
    for (var i = 0; i <= 4; i++) {
        wheelOutput.innerHTML += "Wheel " + "  " + [i + 1] + ": " + " Brand: " + car.wheels[i].brand + " Diameter: " + car.wheels[i].diameter + "<br>";
    }
}
function showWheelForm() {
    var carForm = document.getElementById("create-car-form");
    var carWheel = document.getElementById("create-wheel-form");
    carForm.style.display = "none";
    carWheel.style.display = "block";
}
